﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Interop;
using System.Runtime.InteropServices;

// Original Grid = Height="195" Width="820"

namespace arem.util
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>    

    public partial class TSKeyboard : Window
    {
        public const int Margins = 38;
        public const int AlphaWidth = 584;
        public const int NumWidth = 155;
        public const int FullWidth = 810;

        public const String Normal = "#FF760E0E";
        public const String   Down = "#63760E0E";

        public const String NCAPS = "KBD200";
        public const String NSHIFT = "KBD300";
        public const String NNUM = "NKBD01";
        public const String NFN = "KBD404";

        public const int KSA = (int)KeySpec.IsAlpha
                       , KSC = (int)KeySpec.IsControl
                       , KSE = (int)KeySpec.IsEdit
                       , KSN = (int)KeySpec.IsNum
                       , KSP = (int)KeySpec.IsPerm
                       , KSS = (int)KeySpec.IsSpecial
                       , KSW = (int)KeySpec.IsSwitch     
                       , KSX = (int)KeySpec.IsExtended;  

        const int WS_EX_NOACTIVATE = 0x08000000;
        const int GWL_EXSTYLE = -20;

        [DllImport("user32", SetLastError = true)]
        private extern static int GetWindowLong(IntPtr hwnd, int nIndex);

        [DllImport("user32", SetLastError = true)]
        private extern static int SetWindowLong(IntPtr hwnd, int nIndex, int dwNewValue);

        public Button BCAPS, BLSHIFT, BRSHIFT, BNUM;
        public Button BSCROLL, BLCTRL, BRCTRL, BLALT, BRALT, BFN;
        
        public Keyboard KBD;
        Point pos;
        public TSKeyboard()
        {
            InitializeComponent();
            SetOpKeys();
            KBD = new Keyboard(this, null, App.AppDDM);
            KBD.SetEvents();
            
        }

        private void SetOpKeys()
        {
            BCAPS = KBD200;
            BLSHIFT = KBD300;
            BRSHIFT = KBD304;
            BNUM = NKBD01;
            BSCROLL = CKBD001;
            BLCTRL = KBD400;
            BRCTRL = KBD407;
            BLALT = KBD402;
            BRALT = KBD405;
            BFN = KBD404;
        }
        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            pos = e.GetPosition(this);
        }

        private void Window_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                this.Left += e.GetPosition(this).X - pos.X;
                this.Top += e.GetPosition(this).Y - pos.Y;
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            WindowInteropHelper wih = new WindowInteropHelper(this);
            int exstyle = GetWindowLong(wih.Handle, GWL_EXSTYLE);
            exstyle |= WS_EX_NOACTIVATE;
            SetWindowLong(wih.Handle, GWL_EXSTYLE, exstyle);
            var DWA = System.Windows.SystemParameters.WorkArea;
            this.Top = DWA.Bottom - this.Height;
            this.Left = (DWA.Width- this.Width) /2;
        } 

        private void CmdExit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
        private void CmdAlpha_Click(object sender, RoutedEventArgs e)
        {
            KBD.DisplayMode = DisplayModes.Alpha;  // ShowKeys();
        }
        private void CmdNumeric_Click(object sender, RoutedEventArgs e)
        {
            KBD.DisplayMode = DisplayModes.Numeric; //ShowKeys(false, true);
        }
        private void CmdAlphaNumeric_Click(object sender, RoutedEventArgs e)
        {
            KBD.DisplayMode = DisplayModes.Both; //ShowKeys(true, true);
        }
        private void CmdEnhanced_Click(object sender, RoutedEventArgs e)
        {
            KBD.DisplayMode = DisplayModes.Enhanced; //ShowKeys(true, true, true);
        }

        public Brush GetTBrush(Boolean sts) { return (Brush)new BrushConverter().ConvertFromString((sts) ? Down : Normal); }

        public Boolean GetKey(Dictionary<Button, Key> Keys, Dictionary<Button, Key> EKeys, KBDStatus Status, Button KB, out Key key)
        {
            if (Status.Function)
                return EKeys.TryGetValue(KB, out key);
            else
                return Keys.TryGetValue(KB, out key);
        }
        public void Render(Dictionary<Button, Key> Keys, Dictionary<Button, Key> EKeys, KBDStatus Status)
        {
            // Std rendering
            Render(Keys, Status);            
            // Temp switches background
            BLSHIFT.Background = GetTBrush(Status.LShift);
            BRSHIFT.Background = GetTBrush(Status.RShift);
            BLCTRL.Background = GetTBrush(Status.LControl);
            BRCTRL.Background = GetTBrush(Status.RControl);
            BLALT.Background = GetTBrush(Status.LAlt);
            BRALT.Background = GetTBrush(Status.RAlt);
            BFN.Background = GetTBrush(Status.Function);
            // Extended rendering (FN key based)
            if (EKeys != null && EKeys.Count > 0 && Status.Function) Render(EKeys, Status);
        }
        // Render a single set of keys
        public void Render(Dictionary<Button, Key> Keys, KBDStatus Status)
        {
            Boolean Shift = Status.LShift || Status.RShift;
            foreach (var k in Keys)
            {
                Button b = k.Key as Button;
                Key key = k.Value;
                RenderKey(b, key, Status, Shift);
            }
        }
        // Render a single key
        public void RenderKey(Button b, Key key, KBDStatus Status, Boolean Shift = false)
        {
            if (key.Switches == null || key.Switches[0] == null) return;                        
            switch (key.Switches[0].Name)
                {
                    case NCAPS:
                        RenderContent(b, key, Shift, Status.Caps);
                        break;    
                    case NSHIFT:
                        RenderContent(b, key, Shift);                        
                        break;
                    case NNUM:
                        RenderContent(b, key, Status.NumLock, true);
                        RenderFontSize(b, key, Status.NumLock, 16, 10);                        
                        break;
                    case NFN:
                        RenderContent(b, key, Shift , true);                        
                        break;
                }            
        }
        public void RenderContent(Button b, Key key, Boolean TSwitch, Boolean PSwitch = false )
        {
            if (PSwitch)
                b.Content = (TSwitch) ? key.Face : key.SFace;
            else
                b.Content = (TSwitch) ? key.SFace : key.Face;
            ToolTip tip = b.ToolTip as ToolTip;
            tip.Content = b.Content;            
            
        }
        public void RenderFontSize(Button b, Key key, Boolean TSwitch, double ASize, double ISize)
        {
            b.FontSize = (TSwitch) ? ASize : ISize;
        }

        public void ShowKeys(Boolean Alpha = true, Boolean Numeric = false, Boolean Control = false)
        {
            Visibility AV = (Alpha) ? Visibility.Visible : Visibility.Collapsed;
            Visibility NV = (Numeric) ? Visibility.Visible : Visibility.Collapsed;
            Visibility CV = (Control) ? Visibility.Visible : Visibility.Collapsed;
           
            double w = (Alpha && Numeric && Control) ? FullWidth : Margins + ((Alpha) ? AlphaWidth : 0) + ((Numeric) ? NumWidth : 0);
            
            // Alpha (27 + 36 = 63)
            KBD000.Visibility = AV;
            KBD001.Visibility = AV;
            KBD002.Visibility = AV;
            KBD003.Visibility = AV;
            KBD004.Visibility = AV;
            
            KBD100.Visibility = AV;
            KBD101.Visibility = AV;
            KBD102.Visibility = AV;
            KBD103.Visibility = AV;
            KBD104.Visibility = AV;

            KBD200.Visibility = AV;
            KBD201.Visibility = AV;
            KBD202.Visibility = AV;
            KBD203.Visibility = AV;

            KBD300.Visibility = AV;
            KBD301.Visibility = AV;
            KBD302.Visibility = AV;
            KBD303.Visibility = AV;
            KBD304.Visibility = AV;

            KBD400.Visibility = AV;
            KBD401.Visibility = AV;
            KBD402.Visibility = AV;
            KBD403.Visibility = AV;
            KBD404.Visibility = AV;
            KBD405.Visibility = AV;
            KBD406.Visibility = AV;
            KBD407.Visibility = AV;

            KBD01.Visibility = AV;
            KBD02.Visibility = AV;
            KBD03.Visibility = AV;
            KBD04.Visibility = AV;
            KBD05.Visibility = AV;
            KBD06.Visibility = AV;
            KBD07.Visibility = AV;
            KBD08.Visibility = AV;
            KBD09.Visibility = AV;
            KBD10.Visibility = AV;

            KBD11.Visibility = AV;
            KBD12.Visibility = AV;
            KBD13.Visibility = AV;
            KBD14.Visibility = AV;
            KBD15.Visibility = AV;
            KBD16.Visibility = AV;
            KBD17.Visibility = AV;
            KBD18.Visibility = AV;
            KBD19.Visibility = AV;
            KBD20.Visibility = AV;

            KBD21.Visibility = AV;
            KBD22.Visibility = AV;
            KBD23.Visibility = AV;
            KBD24.Visibility = AV;
            KBD25.Visibility = AV;
            KBD26.Visibility = AV;
            KBD27.Visibility = AV;
            KBD28.Visibility = AV;
            KBD29.Visibility = AV;

            KBD31.Visibility = AV;
            KBD32.Visibility = AV;
            KBD33.Visibility = AV;
            KBD34.Visibility = AV;
            KBD35.Visibility = AV;
            KBD36.Visibility = AV;
            KBD37.Visibility = AV;

            // Numeric (17)
            NKBD01.Visibility = NV;
            NKBD02.Visibility = NV;
            NKBD03.Visibility = NV;
            NKBD04.Visibility = NV;
            NKBD11.Visibility = NV;
            NKBD12.Visibility = NV;
            NKBD13.Visibility = NV;
            NKBD14.Visibility = NV;
            NKBD21.Visibility = NV;
            NKBD22.Visibility = NV;
            NKBD23.Visibility = NV;
            NKBD31.Visibility = NV;
            NKBD32.Visibility = NV;
            NKBD33.Visibility = NV;
            NKBD34.Visibility = NV;
            NKBD41.Visibility = NV;
            NKBD42.Visibility = NV;
            
            // Control (4)
            CKBD001.Visibility = CV;
            CKBD101.Visibility = CV;
            CKBD201.Visibility = CV;
            CKBD301.Visibility = CV;
            CKBD401.Visibility = CV;


            Width = w;            
            
            UpdateLayout();

            }


        public void LoadKeys(Dictionary<Button, Key> Keys, Dictionary<Button, Key> EKeys
                           , ref Button[] CS, ref Button[] SS, ref Button[] NS, ref Button[] ES, ref Button[] PS, ref Button[] TS)
        {

            CS = new Button[] { BCAPS, BLSHIFT, BRSHIFT };
            SS = new Button[] { BLSHIFT, BRSHIFT };
            NS = new Button[] { BNUM };
            ES = new Button[] { BFN };

            PS = new Button[] { BCAPS, BNUM, BSCROLL };
            TS = new Button[] { BLSHIFT, BRSHIFT, BLCTRL, BRCTRL, BLALT, BRALT, BFN };

            Keys.Add(KBD000, new Key("esc", "ESC", "", "", 110, VK._ESCAPE, VK._ESCAPE, 27, 27, 0, 0, KSC, CS));
            Keys.Add(KBD001, new Key("`", "~", "`", "~", 1, VK._OEM_3, VK._OEM_3, 96, 126, 0, 0, KSS, SS));
            Keys.Add(KBD002, new Key("-", "_", "-", "_", 12, VK._OEM_MINUS, 0, 45, 95, 0, 0, KSS, SS));
            Keys.Add(KBD003, new Key("=", "+", "=", "+", 13, VK._OEM_PLUS,  0, 61, 43, 0, 0, KSS, SS));
            Keys.Add(KBD004, new Key("bksp", "BKSP", "", "", 15, VK._BACK, VK._BACK, 8, 8, 0, 0, KSE, CS));
            Keys.Add(KBD01, new Key("1", "!", "1", "!", 2, VK._1, 0, 49, 33, 0, 0, KSN + KSS, SS));
            Keys.Add(KBD02, new Key("2", "@", "2", "@", 3, VK._2, 0, 50, 64, 0, 0, KSN + KSS, SS));
            Keys.Add(KBD03, new Key("3", "#", "3", "#", 4, VK._3, 0, 51, 35, 0, 0, KSN + KSS, SS));
            Keys.Add(KBD04, new Key("4", "$", "4", "$", 5, VK._4, 0, 52, 36, 0, 0, KSN + KSS, SS));
            Keys.Add(KBD05, new Key("5", "%", "5", "%", 6, VK._5, 0, 53, 37, 0, 0, KSN + KSS, SS));
            Keys.Add(KBD06, new Key("6", "^", "6", "^", 7, VK._6, 0, 54, 94, 0, 0, KSN + KSS, SS));
            Keys.Add(KBD07, new Key("7", "&", "7", "&", 8, VK._7, 0, 55, 38, 0, 0, KSN + KSS, SS));
            Keys.Add(KBD08, new Key("8", "*", "8", "*", 9, VK._8, 0, 56, 42, 0, 0, KSN + KSS, SS));
            Keys.Add(KBD09, new Key("9", "(", "9", "(", 10, VK._9, 0, 57, 40, 0, 0, KSN + KSS, SS));
            Keys.Add(KBD10, new Key("0", ")", "0", ")", 11, VK._0, 0, 48, 41, 0, 0, KSN + KSS, SS));
            Keys.Add(KBD100, new Key("tab", "TAB", "", "", 16, VK._TAB, VK._TAB, 9, 9, 0, 0, KSC + KSE, CS));
            Keys.Add(KBD101, new Key("[", "{", "[", "{", 27, VK._OEM_4, VK._OEM_4, 91, 123, 0, 0, KSS, SS));
            Keys.Add(KBD102, new Key("]", "}", "]", "}", 28, VK._OEM_6, VK._OEM_6, 93, 125, 0, 0, KSS, SS));
            Keys.Add(KBD103, new Key("\\", "|", "\\", "|", 29, VK._OEM_5, VK._OEM_5, 92, 124, 0, 0, KSS, SS));
            Keys.Add(KBD104, new Key("del", "DEL", "", "", 76, VK._DELETE, VK._DELETE, 127, 127, 0, 0, KSE, CS));
            Keys.Add(KBD11, new Key("q", "Q", "q", "Q", 17, VK._Q, VK._Q, 113, 81, 0, 0, KSA, CS));
            Keys.Add(KBD12, new Key("w", "W", "w", "W", 18, VK._W, VK._W, 119, 87, 0, 0, KSA, CS));
            Keys.Add(KBD13, new Key("e", "E", "e", "E", 19, VK._E, VK._E, 101, 69, 0, 0, KSA, CS));
            Keys.Add(KBD14, new Key("r", "R", "r", "R", 20, VK._R, VK._R, 114, 82, 0, 0, KSA, CS));
            Keys.Add(KBD15, new Key("t", "T", "t", "T", 21, VK._T, VK._T, 116, 84, 0, 0, KSA, CS));
            Keys.Add(KBD16, new Key("y", "Y", "y", "Y", 22, VK._Y, VK._Y, 121, 89, 0, 0, KSA, CS));
            Keys.Add(KBD17, new Key("u", "U", "u", "U", 23, VK._U, VK._U, 117, 85, 0, 0, KSA, CS));
            Keys.Add(KBD18, new Key("i", "I", "i", "I", 24, VK._I, VK._I, 105, 73, 0, 0, KSA, CS));
            Keys.Add(KBD19, new Key("o", "O", "o", "O", 25, VK._O, VK._O, 111, 79, 0, 0, KSA, CS));
            Keys.Add(KBD20, new Key("p", "P", "p", "P", 26, VK._P, VK._P, 112, 80, 0, 0, KSA, CS));
            Keys.Add(KBD200, new Key("caps", "CAPS", "", "", 30, VK._CAPITAL, VK._CAPITAL, 0, 0, 0, 0, KSW + KSP, CS));
            Keys.Add(KBD201, new Key(";", ":", ";", ":", 40, VK._OEM_1, VK._OEM_1, 59, 58, 0, 0, KSS, SS));
            Keys.Add(KBD202, new Key("'", "\"", "'", "\"", 41, VK._OEM_7, VK._OEM_7, 39, 34, 0, 0, KSS, SS));
            Keys.Add(KBD203, new Key("enter", "ENTER", "", "", 43, VK._RETURN, VK._RETURN, 13, 13, 0, 0, KSE, CS));
            Keys.Add(KBD21, new Key("a", "A", "a", "A", 31, VK._A, VK._A, 97, 65, 0, 0, KSA, CS));
            Keys.Add(KBD22, new Key("s", "S", "s", "S", 32, VK._S, VK._S, 115, 83, 0, 0, KSA, CS));
            Keys.Add(KBD23, new Key("d", "D", "d", "D", 33, VK._D, VK._D, 100, 68, 0, 0, KSA, CS));
            Keys.Add(KBD24, new Key("f", "F", "f", "F", 34, VK._F, VK._F, 102, 70, 0, 0, KSA, CS));
            Keys.Add(KBD25, new Key("g", "G", "g", "G", 35, VK._G, VK._G, 103, 71, 0, 0, KSA, CS));
            Keys.Add(KBD26, new Key("h", "H", "h", "H", 36, VK._H, VK._H, 104, 72, 0, 0, KSA, CS));
            Keys.Add(KBD27, new Key("j", "J", "j", "J", 37, VK._J, VK._J, 106, 74, 0, 0, KSA, CS));
            Keys.Add(KBD28, new Key("k", "K", "k", "K", 38, VK._K, VK._K, 107, 75, 0, 0, KSA, CS));
            Keys.Add(KBD29, new Key("l", "L", "l", "L", 39, VK._L, VK._L, 108, 76, 0, 0, KSA, CS));
            Keys.Add(KBD300, new Key("shift", "SHIFT", "", "", 44, VK._LSHIFT, VK._LSHIFT, 0, 0, 0, 0, KSW));
            Keys.Add(KBD301, new Key(",", "<", ",", "<", 53, VK._OEM_COMMA, VK._OEM_102, 44, 60, 0, 0, KSS, SS));
            Keys.Add(KBD302, new Key(".", ">", ".", ">", 54, VK._OEM_PERIOD, VK._OEM_102, 46, 62, 0, 0, KSS, SS));
            Keys.Add(KBD303, new Key("/", "?", "/", "?", 55, VK._OEM_2, VK._OEM_2, 47, 63, 0, 0, KSS, SS));
            Keys.Add(KBD304, new Key("shift", "SHIFT", "", "", 57, VK._RSHIFT, VK._RSHIFT, 0, 0, 0, 0, KSW));
            Keys.Add(KBD31, new Key("z", "Z", "z", "Z", 46, VK._Z, VK._Z, 122, 90, 0, 0, KSA, CS));
            Keys.Add(KBD32, new Key("x", "X", "x", "X", 47, VK._X, VK._X, 120, 88, 0, 0, KSA, CS));
            Keys.Add(KBD33, new Key("c", "C", "c", "C", 48, VK._C, VK._C, 99, 67, 0, 0, KSA, CS));
            Keys.Add(KBD34, new Key("v", "V", "v", "V", 49, VK._V, VK._V, 118, 86, 0, 0, KSA, CS));
            Keys.Add(KBD35, new Key("b", "B", "b", "B", 50, VK._B, VK._B, 98, 66, 0, 0, KSA, CS));
            Keys.Add(KBD36, new Key("n", "N", "n", "N", 51, VK._N, VK._N, 110, 78, 0, 0, KSA, CS));
            Keys.Add(KBD37, new Key("m", "M", "m", "M", 52, VK._M, VK._M, 109, 77, 0, 0, KSA, CS));
            Keys.Add(KBD400, new Key("ctrl", "CTRL", "", "", 58, VK._LCONTROL, VK._LCONTROL, 0, 0, 0, 0, KSW));
            Keys.Add(KBD401, new Key("win", "WIN", "", "", 127, VK._LWIN, VK._LWIN, 0, 0, 0, 0, KSC));
            Keys.Add(KBD402, new Key("alt", "ALT", "", "", 60, VK._LMENU, VK._LMENU, 0, 0, 0, 0, KSW));
            Keys.Add(KBD403, new Key(" ", " ", " ", " ", 61, VK._SPACE, VK._SPACE, 32, 32, 0, 0, KSS));
            Keys.Add(KBD404, new Key("fn", "FN", "", "", 0, VK._OEM_FN, 0, 0, 0, 0, 0, KSW));
            Keys.Add(KBD405, new Key("alt", "ALT", "", "", 62, VK._RMENU, VK._RMENU, 0, 0, 0, 0, KSW));
            Keys.Add(KBD406, new Key("menu", "MENU", "", "", 129, VK._MENU, VK._MENU, 0, 0, 0, 0, KSC));
            Keys.Add(KBD407, new Key("ctrl", "CTRL", "", "", 64, VK._RCONTROL, VK._RCONTROL, 0, 0, 0, 0, KSW));
            Keys.Add(CKBD001, new Key("scroll", "SCROLL", "", "", 125, VK._SCROLL, VK._SCROLL, 0, 0, 0, 0, KSW + KSP));
            Keys.Add(CKBD101, new Key("break", "BREAK", "", "", 126, VK._CANCEL, VK._CANCEL, 0, 0, 0, 0, KSC));
            Keys.Add(CKBD201, new Key("print screen", "PRINT SCREEN", "", "", 124, VK._SNAPSHOT, VK._SNAPSHOT, 0, 0, 0, 0, KSC));
            Keys.Add(CKBD301, new Key("pause", "PAUSE", "", "", 126, VK._PAUSE, VK._PAUSE, 0, 0, 0, 0, KSC));
            Keys.Add(CKBD401, new Key("sys req", "SYS REQ", "", "", 124, 0, 0, 0, 0, 0, 0, KSC));
            Keys.Add(NKBD01, new Key("num", "NUM", "", "", 90, VK._NUMLOCK, VK._NUMLOCK, 0, 0, 0, 0, KSW + KSP));
            Keys.Add(NKBD02, new Key("/", "/", "/", "/", 95, VK._DIVIDE, VK._DIVIDE, 47, 47, 0, KSS));
            Keys.Add(NKBD03, new Key("*", "*", "*", "*", 100, VK._MULTIPLY, VK._MULTIPLY, 42, 42, 0, KSS));
            Keys.Add(NKBD04, new Key("-", "-", "-", "-", 105, VK._SUBTRACT, VK._SUBTRACT, 45, 45, 0, KSS));
            Keys.Add(NKBD11, new Key("7", "home", "7", "", 91, VK._NUMPAD7, VK._HOME, 55, 0, 0, 0, KSN + KSE, NS));
            Keys.Add(NKBD12, new Key("8", "▲", "8", "", 96, VK._NUMPAD8, VK._UP, 56, 0, 0, 0, KSN + KSE, NS));
            Keys.Add(NKBD13, new Key("9", "pg up", "9", "", 101, VK._NUMPAD9, VK._PRIOR, 57, 0, 0, 0, KSN + KSE, NS));
            Keys.Add(NKBD14, new Key("+", "+", "+", "+", 106, VK._ADD, VK._ADD, 43, 43, 0, KSS));
            Keys.Add(NKBD21, new Key("4", "◄", "4", "", 92, VK._NUMPAD4, VK._LEFT, 52, 0, 0, 0, KSN + KSE, NS));
            Keys.Add(NKBD22, new Key("5", "←", "5", "", 97, VK._NUMPAD5, VK._BACK, 53, 0, 0, 0, KSN + KSE, NS));
            Keys.Add(NKBD23, new Key("6", "►", "6", "", 102, VK._NUMPAD6, VK._RIGHT, 54, 0, 0, 0, KSN + KSE, NS));
            Keys.Add(NKBD31, new Key("1", "end", "1", "", 93, VK._NUMPAD1, VK._END, 49, 0, 0, 0, KSN + KSE, NS));
            Keys.Add(NKBD32, new Key("2", "▼", "2", "", 98, VK._NUMPAD2, VK._DOWN, 50, 0, 0, 0, KSN + KSE, NS));
            Keys.Add(NKBD33, new Key("3", "pg dn", "3", "", 103, VK._NUMPAD3, VK._NEXT, 51, 0, 0, 0, KSN + KSE, NS));
            Keys.Add(NKBD34, new Key("enter", "ENTER", "", "", 108, VK._RETURN, VK._RETURN, 13, 13, 0, 0, KSE));
            Keys.Add(NKBD41, new Key("0", "insert", "0", "", 99, VK._NUMPAD0, VK._INSERT, 48, 0, 0, 0, KSN + KSE, NS));
            Keys.Add(NKBD42, new Key(".", "del", ".", "", 104, VK._DECIMAL, VK._DELETE, 46, 127, 0, 0, KSS + KSE, NS));

            EKeys.Add(KBD01, new Key("f1", "F1", "", "", 2, VK._F1, VK._F1, 0, 0, 0, 0, KSX, ES));
            EKeys.Add(KBD02, new Key("f2", "F2", "", "", 3, VK._F2, VK._F2, 0, 0, 0, 0, KSX, ES));
            EKeys.Add(KBD03, new Key("f3", "F3", "", "", 4, VK._F3, VK._F3, 0, 0, 0, 0, KSX, ES));
            EKeys.Add(KBD04, new Key("f4", "F4", "", "", 5, VK._F4, VK._F4, 0, 0, 0, 0, KSX, ES));
            EKeys.Add(KBD05, new Key("f5", "F5", "", "", 6, VK._F5, VK._F5, 0, 0, 0, 0, KSX, ES));
            EKeys.Add(KBD06, new Key("f6", "F6", "", "", 7, VK._F6, VK._F6, 0, 0, 0, 0, KSX, ES));
            EKeys.Add(KBD07, new Key("f7", "F7", "", "", 8, VK._F7, VK._F7, 0, 0, 0, 0, KSX, ES));
            EKeys.Add(KBD08, new Key("f8", "F8", "", "", 9, VK._F8, VK._F8, 0, 0, 0, 0, KSX, ES));
            EKeys.Add(KBD09, new Key("f9", "F9", "", "", 10, VK._F9, VK._F9, 0, 0, 0, 0, KSX, ES));
            EKeys.Add(KBD10, new Key("f10", "F10", "", "", 11, VK._F10, VK._F10, 0, 0, 0, 0, KSX, ES));
            EKeys.Add(KBD002, new Key("f11", "F11", "", "", 12, VK._F11, VK._F11, 0, 0, 0, 0, KSX, ES));
            EKeys.Add(KBD003, new Key("f12", "F12", "", "", 13, VK._F12, VK._F12, 0, 0, 0, 0, KSX, ES));

            foreach (var key in Keys)
            {
                ToolTip tip = new ToolTip();
                tip.FontSize = 24;
                tip.Content = key.Key.Content;
                key.Key.ToolTip = tip;
            }
        }
        }
        
    }

