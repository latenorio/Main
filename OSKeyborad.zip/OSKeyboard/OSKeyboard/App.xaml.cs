﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Windows;

namespace arem.util
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        public static DisplayModes AppDDM = DisplayModes.Enhanced;
        public static void SetDDM(String dm)
        {
            switch(dm)
            {
               case "A": AppDDM = DisplayModes.Alpha; break;
               case "B": AppDDM = DisplayModes.Both; break;
               case "E": AppDDM = DisplayModes.Enhanced; break;
               case "N": AppDDM = DisplayModes.Numeric; break;
            }
        }
        /// <summary>
        /// Application Entry Point.
        /// </summary>
        [System.STAThreadAttribute()]
        public static void Main(String[] args)
        {
            if (args.Length > 0) SetDDM(args[0].Substring(0,1).ToUpper());
                
                    arem.util.App app = new arem.util.App();
            app.InitializeComponent();
            app.Run();
        }

    }
}
