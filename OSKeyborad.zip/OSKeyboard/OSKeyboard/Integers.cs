﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Excercise
{
    class Integers
    {
        protected SortedSet<int> SS = new SortedSet<int>;

        public virtual int Min { get { return SS.Min; } }
        public virtual int Max { get { return SS.Max; } }

        public void AppendValues(IEnumerable<int> ints)
        {
            foreach (var i in ints) SS.Add(i);
        }
        public SortedSet<int> GetBoundaries()
        {
            SortedSet<int> ss = new SortedSet<int>();
            ss.Add(Min);
            ss.Add(Max);
            return ss;
        }
        public SortedSet<int> GetDistinctValuesSorted()
        {
            SortedSet<int> ss = new SortedSet<int>();
            int? v = null;
            foreach (var i in SS)
            {
                if (i > Max) break; // Condition only relevant to the descending class
                if ( v == null || (int)v != i) ss.Add(i);
                v = i;
            }
            return ss;            
        }
        public SortedSet<int> GetMissingValues()
        {
            SortedSet<int> ss = new SortedSet<int>();
            
            for ( int i = SS.Min; i <= Max; i++ )
            {
                if (!SS.Contains(i)) ss.Add(i);
                            }
            return ss;
        }

    }
    class LimitedIntegers : Integers
    {
        private int? hr = null;
        public int? HighestRelevant { get { return hr; } set { hr = value; } }
        public override int Max 
        { 
            get  { return (hr != null && (int)hr < SS.Max)? SS.GetViewBetween(Min,(int)hr).Max:SS.Max; } 
        }
    }

}