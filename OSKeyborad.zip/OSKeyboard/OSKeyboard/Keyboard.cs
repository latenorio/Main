﻿// #define K_DEBUG

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Runtime.InteropServices;

namespace arem.util
{
    // Keys specifications enumeration
    public enum KeySpec
    {
        IsAlpha   =  2,
        IsNum     =  4,
        IsSpecial =  8,
        IsSwitch  = 16,
        IsPerm    = 32,
        IsEdit    = 64,
        IsControl = 128,
        IsExtended = 256
    }
    // Operation Modes
    public enum OperationModes { Attached, Detached }
    // Display Modes
    public enum DisplayModes { Alpha, Numeric, Both, Enhanced }
    // Key types
    public enum KeyTypes { Perm, Temp, Reg }
    // Key values structure
    public struct Key
    {
        public String Face;       // normal display
        public String SFace;      // shifted display (Caps lock inversion for alpha keys) 
        public String Value;      // normal character return value (for alpha and num keys)  
        public String SValue;     // shifted character return value (for alpha and num keys)
        public byte ScanCode;      // Keyboard physical key value
        public byte VirtualCode;   // Windows virtual values 
        public byte VirtualSCode;
        public int Code;          // ASCII / UNICODE values  
        public int ShiftCode;     // Shift+KEY value   
        public int AltCode;       // Alt+KEY value
        public int CtrlCode;      // Control+KEY value
        public int KeySpec;       // Key specification using enum values   
        public Button[] Switches; // Asocieted switches
        public Boolean Status;    // on/off for switches
        public Key(String f="", String sf="", String v="", String sv="", byte sc = 0, byte vc = 0, byte vsc =0
                 , int c = 0, int shc = 0, int ac = 0, int cc = 0, int ks = 0, Button[] sw = null, Boolean sts = false)
        {
            Face = f;
            SFace = sf;
            Value = v;
            SValue = sv;
            ScanCode = sc;
            VirtualCode = vc;
            VirtualSCode = vsc;
            Code = c;
            ShiftCode = shc;
            AltCode = ac;
            CtrlCode = cc;
            KeySpec = ks;
            Switches = sw;
            Status = sts;
        }        
    }
    // Keyboard status
    public struct KBDStatus
    {
        public Boolean LShift;
        public Boolean RShift;
        public Boolean LAlt;
        public Boolean RAlt;
        public Boolean LControl;
        public Boolean RControl;
        public Boolean Function;
        public Boolean Caps;
        public Boolean NumLock;
        public Boolean ScrollLock;
        public Boolean AltNum;
        public KBDStatus(Boolean ls = false, Boolean rs = false, Boolean la = false, Boolean ra = false, Boolean lc = false, Boolean rc = false
                       , Boolean f = false, Boolean p = false, Boolean n = true,  Boolean r = false, Boolean l = false)
        {
            LShift = ls;
            RShift = rs;
            LAlt = la;
            RAlt = ra;
            LControl = lc;
            RControl = rc;
            Function = f;
            Caps = p;
            NumLock = n;
            ScrollLock = r;
            AltNum = l; 
        }
        public KBDStatus(KBDStatus s)
        {
            LShift = s.LShift;
            RShift = s.LShift;
            LAlt = s.LAlt;
            RAlt = s.RAlt;
            LControl = s.LControl;
            RControl = s.RControl;
            
            Caps = s.Caps;
            NumLock = s.NumLock;
            ScrollLock = s.ScrollLock;

            Function = s.Function;
            AltNum = s.AltNum;
        }
        public void ResetTemp()
        {
            LShift = false;
            RShift = false;
            LAlt = false;
            RAlt = false;
            LControl = false;
            RControl = false;

            Function = false;
            AltNum = false;
        }
        public void ToggleSwitch(int Code)
        {
            switch (Code)
            {
                case VK._CAPITAL:
                    Caps = !Caps;
                    break;
                case VK._NUMLOCK:
                    NumLock = !NumLock;
                    break;
                case VK._SCROLL:
                    ScrollLock = !ScrollLock;
                    break;       
                case VK._LSHIFT:
                    LShift = !LShift;
                    break;
                case VK._RSHIFT:
                    RShift = !RShift;
                    break;
                case VK._LCONTROL:
                    LControl = !LControl;
                    break;
                case VK._RCONTROL:
                    RControl = !RControl;
                    break;
                case VK._LMENU:
                    LAlt = !LAlt;
                    break;
                case VK._RMENU:
                    RAlt = !RAlt;
                    break;
                case VK._OEM_FN:
                    Function = !Function;
                    break;
            }
        }
        public Boolean ReadSwitch(int Code)
        {
            switch (Code)
            {
                case VK._CAPITAL:  return Caps;                    
                case VK._NUMLOCK:  return NumLock;                    
                case VK._SCROLL:   return ScrollLock;                   
                case VK._LSHIFT:   return LShift;                    
                case VK._RSHIFT:   return RShift;                    
                case VK._LCONTROL: return LControl;                    
                case VK._RCONTROL: return RControl;
                case VK._LMENU:    return LAlt;
                case VK._RMENU:    return RAlt;
                case VK._OEM_FN:   return Function;
                default:           return false;                    
            }
        }
       
    }
    #region Virtual Keys Constants
    public class EVENTKEYF
    {
        public const int KEYUP = 0X2,         // Release key        
                         EXTENDEDKEY = 0X1;  // Extended keyboard
    }
    public class VK
    {
        public const int _LBUTTON = 0x1, //Left mouse button.
                         _RBUTTON = 0x2, //Right mouse button.
                         _CANCEL = 0x3, //Used for control-break processing.
                         _MBUTTON = 0x4, //''Middle mouse button (3-button mouse).
                         _XBUTTON1 = 0x5, //mouse x button 1.
                         _XBUTTON2 = 0x6; //mouse x button 2.

        public const int _BACK = 0x08,    /* editing keys */
                         _TAB = 0x09,
                         _CLEAR = 0x0C,
                         _RETURN = 0x0D,
                         _SHIFT = 0x10,
                         _CONTROL = 0x11,
                         _MENU = 0x12,
                         _PAUSE = 0x13,
                         _CAPITAL = 0x14,
                         _KANA = 0x15,
                         _HANGEUL = 0x15,
                         _HANGUL = 0x15,
                         _JUNJA = 0x17,
                         _FINAL = 0x18,
                         _HANJA = 0x19,
                         _KANJI = 0x19,
                         _ESCAPE = 0x1B,
                         _CONVERT = 0x1C,
                         _NONCONVERT = 0x1D,
                         _ACCEPT = 0x1E,
                         _MODECHANGE = 0x1F,
                         _SPACE = 0x20,
                         _PRIOR = 0x21,
                         _NEXT = 0x22,
                         _END = 0x23,
                         _HOME = 0x24,
                         _LEFT = 0x25,
                         _UP = 0x26,
                         _RIGHT = 0x27,
                         _DOWN = 0x28,
                         _SELECT = 0x29,
                         _PRINT = 0x2A,
                         _EXECUTE = 0x2B,
                         _SNAPSHOT = 0x2C,
                         _INSERT = 0x2D,
                         _DELETE = 0x2E,
                         _HELP = 0x2F;

        public const int _0 = 0x30;
        public const int _1 = 0x31;
        public const int _2 = 0x32;
        public const int _3 = 0x33;
        public const int _4 = 0x34;
        public const int _5 = 0x35;
        public const int _6 = 0x36;
        public const int _7 = 0x37;
        public const int _8 = 0x38;
        public const int _9 = 0x39;
        public const int _A = 0x41;
        public const int _B = 0x42;
        public const int _C = 0x43;
        public const int _D = 0x44;
        public const int _E = 0x45;
        public const int _F = 0x46;
        public const int _G = 0x47;
        public const int _H = 0x48;
        public const int _I = 0x49;
        public const int _J = 0x4A;
        public const int _K = 0x4B;
        public const int _L = 0x4C;
        public const int _M = 0x4D;
        public const int _N = 0x4E;
        public const int _O = 0x4F;
        public const int _P = 0x50;
        public const int _Q = 0x51;
        public const int _R = 0x52;
        public const int _S = 0x53;
        public const int _T = 0x54;
        public const int _U = 0x55;
        public const int _V = 0x56;
        public const int _W = 0x57;
        public const int _X = 0x58;
        public const int _Y = 0x59;
        public const int _Z = 0x5A;

        public const int _LWIN = 0x5B;
        public const int _RWIN = 0x5C;
        public const int _APPS = 0x5D;
        public const int _SLEEP = 0x5F;
        public const int _NUMPAD0 = 0x60;
        public const int _NUMPAD1 = 0x61;
        public const int _NUMPAD2 = 0x62;
        public const int _NUMPAD3 = 0x63;
        public const int _NUMPAD4 = 0x64;
        public const int _NUMPAD5 = 0x65;
        public const int _NUMPAD6 = 0x66;
        public const int _NUMPAD7 = 0x67;
        public const int _NUMPAD8 = 0x68;
        public const int _NUMPAD9 = 0x69;
        public const int _MULTIPLY = 0x6A;
        public const int _ADD = 0x6B;
        public const int _SEPARATOR = 0x6C;
        public const int _SUBTRACT = 0x6D;
        public const int _DECIMAL = 0x6E;
        public const int _DIVIDE = 0x6F;
        public const int _F1 = 0x70;
        public const int _F2 = 0x71;
        public const int _F3 = 0x72;
        public const int _F4 = 0x73;
        public const int _F5 = 0x74;
        public const int _F6 = 0x75;
        public const int _F7 = 0x76;
        public const int _F8 = 0x77;
        public const int _F9 = 0x78;
        public const int _F10 = 0x79;
        public const int _F11 = 0x7A;
        public const int _F12 = 0x7B;
        public const int _F13 = 0x7C;
        public const int _F14 = 0x7D;
        public const int _F15 = 0x7E;
        public const int _F16 = 0x7F;
        public const int _F17 = 0x80;
        public const int _F18 = 0x81;
        public const int _F19 = 0x82;
        public const int _F20 = 0x83;
        public const int _F21 = 0x84;
        public const int _F22 = 0x85;
        public const int _F23 = 0x86;
        public const int _F24 = 0x87;
        public const int _NUMLOCK = 0x90;
        public const int _SCROLL = 0x91;

        public const int _LSHIFT = 0xA0, /* SHIFT keys */
                         _RSHIFT = 0xA1,
                         _LCONTROL = 0xA2, /* CONTROL keys */
                         _RCONTROL = 0xA3,
                         _LMENU = 0xA4, /* MENU keys */
                         _RMENU = 0xA5,

                         _BROWSER_BACK = 0xA6, /* Browser Buttons */
                         _BROWSER_FORWARD = 0xA7,
                         _BROWSER_REFRESH = 0xA8,
                         _BROWSER_STOP = 0xA9,
                         _BROWSER_SEARCH = 0xAA,
                         _BROWSER_FAVORITES = 0xAB,
                         _BROWSER_HOME = 0xAC,

                         _VOLUME_MUTE = 0xAD, /* Multimedia buttons */
                         _VOLUME_DOWN = 0xAE,
                         _VOLUME_UP = 0xAF,
                         _MEDIA_NEXT_TRACK = 0xB0,
                         _MEDIA_PREV_TRACK = 0xB1,
                         _MEDIA_STOP = 0xB2,
                         _MEDIA_PLAY_PAUSE = 0xB3,
                         _LAUNCH_MAIL = 0xB4,
                         _LAUNCH_MEDIA_SELECT = 0xB5,
                         _LAUNCH_APP1 = 0xB6,
                         _LAUNCH_APP2 = 0xB7;

        public const int _OEM_1 = 0xBA,        /* For the US standard keyboard, the ';:' key */
                         _OEM_PLUS = 0xBB,        /* For any country/region, the '+' key */
                         _OEM_COMMA = 0xBC,        /* For any country/region, the ',' key */
                         _OEM_MINUS = 0xBD,        /* For any country/region, the '-' key */
                         _OEM_PERIOD = 0xBE,        /* For any country/region, the '.' key */
                         _OEM_2 = 0xBF,        /* For the US standard keyboard, the '/?' key */
                         _OEM_3 = 0xC0,        /* For the US standard keyboard, the '`~' key */
                         _OEM_4 = 0xDB,        /* For the US standard keyboard, the '[{' key */
                         _OEM_5 = 0xDC,        /* For the US standard keyboard, the '\|' key */
                         _OEM_6 = 0xDD,        /* For the US standard keyboard, the ']}' key */
                         _OEM_7 = 0xDE,        /* For the US standard keyboard, the 'single-quote/double-quote' key */
                         _OEM_8 = 0xDF,        /* Used for miscellaneous characters; it can vary by keyboard. */
                         _OEM_102 = 0xE2,        /* Either the angle bracket key or the backslash key on the RT 102-key keyboard */

                         _PROCESSKEY = 0xE5,        /* IME PROCESS key */

                         _PACKET = 0xE7,        /* Used to pass Unicode characters as if they were keystrokes. 
                                                       * The _PACKET key is the low word of a 32-bit Virtual Key value used for non-keyboard input methods. 
                                                       * For more information, see Remark in KEYBDINPUT, SendInput, WM_KEYDOWN, and WM_KEYUP */
                         _ATTN = 0xF6,        /* Attn key */
                         _CRSEL = 0xF7,        /* CrSel key */
                         _EXSEL = 0xF8,        /* ExSel key */
                         _EREOF = 0xF9,        /* Erase EOF key */
                         _PLAY = 0xFA,        /* Play key */
                         _ZOOM = 0xFB,        /* Zoom key */
                         _NONAME = 0xFC,        /* Reserved */
                         _PA1 = 0xFD,        /* PA1 key */
                         _OEM_CLEAR = 0xFE,        /* Clear key */
                         _OEM_FN = 0xFF;
    }
    #endregion Virtual Keys Constants
/* 
 * Keyboard class resposibilities:
 * 
 * - Turn clicks into keyboard events and send them to the active client
 * - Handle/ interpret on screen keyboard functions properly
 * 
 */
public class Keyboard
{
#region Windows API Functions

        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        private static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, UIntPtr dwExtraInfo);

#endregion Windows API Functions        
           
        private Dictionary<Button,Key> Keys = new Dictionary<Button,Key>();
        private Dictionary<Button, Key> EKeys = new Dictionary<Button, Key>();
        private KBDStatus Status;
        
        private Button[] CSwitches;
        private Button[] SSwitches;
        private Button[] NSwitches;
        private Button[] ESwitches;
        
        private Button[] PSwitches;
        private Button[] TSwitches;

        private IInputElement IIE;
        private TSKeyboard TSKBD;
        private OperationModes OpMode;
        private DisplayModes DispMode;

#if K_DEBUG 
   public static void Event(byte bVk, byte bScan, uint dwFlags, UIntPtr dwExtraInfo) { MessageBox.Show(" Code "+ bVk + " Scan "+ bScan + " Event " + ((dwFlags == 0)? "down":"up")); }
#else
   public static void Event(byte bVk, byte bScan, uint dwFlags, UIntPtr dwExtraInfo) { keybd_event(bVk,bScan,dwFlags,dwExtraInfo); }
#endif

    public static byte GetVirtualCode(Key key, Button[] NS, KBDStatus s)  { return (!s.NumLock && InSet(key.Switches, NS)) ? key.VirtualSCode : key.VirtualCode; }

    public static Boolean InSet(Button b, Button[] buttons)
        {
            if (b == null || buttons == null) return false;
            foreach (var btn in buttons)
            {
                if (b == btn) return true;
            }
            return false;
        }
    public static Boolean InSet(Button[] sbuttons, Button[] buttons)
        {
            if (sbuttons == null || buttons == null) return false;
            foreach (var b in sbuttons) if (InSet(b,buttons)) return true;            
            return false;
        }

#region Public properties
        public TSKeyboard Form { get { return TSKBD; } set { TSKBD = value; } }

        public OperationModes OperationMode { get { return OpMode; } set { OpMode = value; } }

        public DisplayModes DisplayMode { 
                                          get { return DispMode; } 
                                          set 
                                          { DispMode = value; 
                                              switch(DispMode)
                                              {
                                               case DisplayModes.Alpha:
                                               TSKBD.ShowKeys();
                                               break;
                                               case DisplayModes.Numeric:                                               
                                               TSKBD.ShowKeys(false, true);
                                               break;
                                               case DisplayModes.Both:
                                               TSKBD.ShowKeys(true, true);
                                               break;
                                               case DisplayModes.Enhanced:
                                               TSKBD.ShowKeys(true, true, true);
                                               break;
                                              }
                                              Status.NumLock = (DispMode == DisplayModes.Numeric);
                                              if (DispMode != DisplayModes.Alpha) Render();
                                        } }
        public Boolean ExtendedKeys { get { return EKeys != null && EKeys.Count > 0; } }
        public Boolean Numlock { get { return Status.NumLock; } set { Status.NumLock = value; } }
        public Boolean Capslock { get { return Status.Caps; } set { Status.Caps = value; } }
        public Boolean Scrolllock { get { return Status.ScrollLock; } set { Status.ScrollLock = value; } } 
#endregion

        public Keyboard(TSKeyboard tsk, DisplayModes DMode = DisplayModes.Enhanced, IInputElement iie = null) : this(tsk,iie,DMode)
        {
        }
        public Keyboard(TSKeyboard tsk, IInputElement iie = null, DisplayModes DMode = DisplayModes.Enhanced)
        {
            TSKBD = tsk;
            IIE = iie;
            OperationMode = (iie == null)? OperationModes.Detached:OperationModes.Attached;
            DisplayMode = DMode;

            Status = new KBDStatus();            
            LoadKeys();
            Render();
        }
        public void Render() { TSKBD.Render(Keys, EKeys, Status); }
        public void LoadKeys() { TSKBD.LoadKeys(Keys, EKeys, ref CSwitches, ref SSwitches, ref NSwitches, ref ESwitches, ref PSwitches, ref TSwitches); }
        public void SetEvents()
        {

            foreach (var k in Keys)
            {
                Button b = k.Key as Button;
                b.Click += new RoutedEventHandler(KBD_Click);
            }            

        }
       
        public KeyTypes GetKeyType(Button b) { return InSet(b, PSwitches) ? KeyTypes.Perm : (InSet(b, TSwitches)) ? KeyTypes.Temp : KeyTypes.Reg; }
        
        public void ProcessKey(Button b, Key k)
        {
            KeyTypes KType = GetKeyType(b);
            if (OperationMode == OperationModes.Attached && IIE != null)
            {
                if (!IIE.IsKeyboardFocused && IIE.Focusable && IIE.IsEnabled) IIE.Focus();                
            }
            // Process the key regular / perm switch or temp switch
            if (KType != KeyTypes.Temp) { SetKey(k, -1); } else { SetTempKey(k); }

            // Release the temp switches for regular keys or togle the corresponding perm/temp switch
            if (KType == KeyTypes.Reg) { ReleaseTempKeys(); } else { Status.ToggleSwitch(k.VirtualCode); }           
        }

        public void SetKey(Key k, long EK = 0)
        {
            if (EK < 0)
            { // Press and release it
                SetKey(k);
                SetKey(k, (uint)EVENTKEYF.KEYUP);
            }
            else // Press or release it
                Event(GetVirtualCode(k,NSwitches,Status), k.ScanCode, (uint)EK, (UIntPtr)0);
        }

        public void ReleaseTempKeys()
        {
            Key key; 
            foreach (Button b in TSwitches)
            {
                if (Keys.TryGetValue(b, out key) && Status.ReadSwitch(key.VirtualCode))  
                {  
                    SetTempKey(key, true);
                    Status.ToggleSwitch(key.VirtualCode);
                }
            }
        }
        public void SetTempKey(Key k, Boolean isSet = false)
        {
            uint ek = (isSet || Status.ReadSwitch(k.VirtualCode)) ? ((uint)EVENTKEYF.KEYUP) : 0;
            SetKey(k, ek);            
        }
        
        public void KBD_Click(object sender, RoutedEventArgs e) { KBDEvent((Button)sender); }

        public void KBDEvent(Button KB)
        {            
            Key key;           
            if (TSKBD.GetKey(Keys,EKeys,Status,KB, out key))
            {
                // Process the key                
                ProcessKey(KB, key);
                Render();                
            }
        }
        
        public void KBDEvent(byte bVk, byte bScan, uint dwFlags, UIntPtr dwExtraInfo) { keybd_event(bVk, bScan, dwFlags, dwExtraInfo); }        
}
}
