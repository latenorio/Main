﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _21stMortgageInterviewApplication
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private int[] GenList()
        {
            int[] il = null;
            String[] sl = TBInput.Text.Split(",");
            il = new int[sl.Length];

            for (int ix = 0; ix < sl.Length; ix++)
            {
                if( !int.TryParse(sl[ix],out il[ix]))
                {
                    MessageBox.Show("Conversion error " + (ix+1).ToString() + " position");
                    ShowResult();
                    return null; 
                }

            }

            return il;
        }
        private void ShowResult(int res = 0)
        {
            TBResult.Text = res.ToString();
            if (res > 0) TBResult.Foreground = new SolidColorBrush(Colors.Green);
            else if (res < 0) TBResult.Foreground = new SolidColorBrush(Colors.Red);
            else TBResult.Foreground = new SolidColorBrush(Colors.Black);

        }
        private void Largest_Click(object sender, RoutedEventArgs e)
        {
            int[] il = GenList();
            int lg = 0; 
            if (il != null)
            {
                lg = il[0];
                foreach (int i in il) if (i > lg) lg = i;
            }
            ShowResult(lg);
        }

        private void Odd_Click(object sender, RoutedEventArgs e)
        {
            int[] il = GenList();
            int sum = 0;
            if (il != null)
            {
                foreach (int i in il) if (i % 2 != 0) sum += i;
            }
            ShowResult(sum);
        }

        private void Even_Click(object sender, RoutedEventArgs e)
        {
            int[] il = GenList();
            int sum = 0;
            if (il != null)
            {
                foreach (int i in il) if (i % 2 == 0) sum += i;
            }
            ShowResult(sum);
        }
    }
}
